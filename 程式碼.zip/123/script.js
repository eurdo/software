document.addEventListener('DOMContentLoaded', () => {
  const board = document.getElementById('board');
  const modal = document.getElementById('winnerModal');
  const winnerText = document.getElementById('winnerText');
  const restartBtn = document.getElementById('restartBtn');

  let cells = Array(9).fill(null);
  let currentPlayer = 'X';
  let gameOver = false;

  function createBoard() {
    board.innerHTML = '';
    cells.forEach((_, i) => {
      const cell = document.createElement('div');
      cell.classList.add('cell');
      cell.addEventListener('click', () => handleClick(i));
      board.appendChild(cell);
    });
  }

  function handleClick(i) {
    if (cells[i] || gameOver) return;
    cells[i] = currentPlayer;
    board.children[i].textContent = currentPlayer;

    if (checkWinner()) {
      showWinner(currentPlayer);
      gameOver = true;
    } else if (cells.every(cell => cell)) {
      showWinner('平手');
      gameOver = true;
    } else {
      currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    }
  }

  function checkWinner() {
    const wins = [
      [0,1,2],[3,4,5],[6,7,8],
      [0,3,6],[1,4,7],[2,5,8],
      [0,4,8],[2,4,6]
    ];
    return wins.some(([a,b,c]) => cells[a] && cells[a] === cells[b] && cells[a] === cells[c]);
  }

  function showWinner(winner) {
    winnerText.textContent = winner === '平手' ? '平手！再來一局？' : `${winner} 獲勝！🎉`;
    modal.style.display = 'flex';
  }

  restartBtn.addEventListener('click', () => {
    cells.fill(null);
    currentPlayer = 'X';
    gameOver = false;
    modal.style.display = 'none';
    createBoard();
  });

  createBoard();
});
